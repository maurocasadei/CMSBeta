<?php

/* admin/macrocategorieMag/admin_macrocategorieMag_index.html.twig */
class __TwigTemplate_e20d26a2b6f0ce12e71e0d0db6aee8cc819736cd89a81a812056881e333ef2c0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate(":admin:base_admin.html.twig", "admin/macrocategorieMag/admin_macrocategorieMag_index.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return ":admin:base_admin.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        echo " ";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("macrocategorieMag.title.plural"), "html", null, true);
        echo " ";
    }

    // line 5
    public function block_content($context, array $blocks = array())
    {
        // line 6
        echo "    <ul class=\"breadcrumb\">
        <li><a href=\"";
        // line 7
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_home");
        echo "\">Home</a></li>
        <li class=\"active\">";
        // line 8
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("macrocategorieMag.title.plural"), "html", null, true);
        echo "</li>
    </ul>

    ";
        // line 11
        $this->loadTemplate("admin/_flashbag.html.twig", "admin/macrocategorieMag/admin_macrocategorieMag_index.html.twig", 11)->display($context);
        // line 12
        echo "
    <div class=\"row margin-vertical-md\">
        <div class=\"col-md-8\">
            <h1 class=\"h-btn-line\">";
        // line 15
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("macrocategorieMag.title.plural"), "html", null, true);
        echo "</h1>
        </div>
        <div class=\"col-md-4 text-right\">
            <a href=\"";
        // line 18
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_macrocategorieMag_new");
        echo "\" class=\"btn btn-primary btn-sm\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("macrocategorieMag.add"), "html", null, true);
        echo "</a>
        </div>
    </div>
\t
    <table class=\"table table-striped table-hover \">
        <thead>
        <tr>
            <th>#</th>
            <th>";
        // line 26
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("macrocategorieMag.name"), "html", null, true);
        echo "</th>
            <th>";
        // line 27
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("macrocategorieMag.parent"), "html", null, true);
        echo "</th>
            ";
        // line 30
        echo " 
            ";
        // line 31
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["translations"]) ? $context["translations"] : null));
        foreach ($context['_seq'] as $context["_key"] => $context["translation"]) {
            // line 32
            echo "                <th>";
            echo twig_escape_filter($this->env, $this->getAttribute($context["translation"], "name", array()), "html", null, true);
            echo "</th>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['translation'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 34
        echo "        </tr>
        </thead>
        <tbody>
        ";
        // line 37
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["categories"]) ? $context["categories"] : null));
        $context['loop'] = array(
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        );
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["macrocategorieMag"]) {
            // line 38
            echo "            <tr>
                <td>";
            // line 39
            echo twig_escape_filter($this->env, $this->getAttribute($context["loop"], "index", array()), "html", null, true);
            echo "</td>
                <td>";
            // line 40
            echo twig_escape_filter($this->env, $this->getAttribute($context["macrocategorieMag"], "name", array()), "html", null, true);
            echo "</td>
                <td>";
            // line 41
            echo twig_escape_filter($this->env, (($this->getAttribute($this->getAttribute($context["macrocategorieMag"], "parent", array(), "any", false, true), "name", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute($this->getAttribute($context["macrocategorieMag"], "parent", array(), "any", false, true), "name", array()), "-")) : ("-")), "html", null, true);
            echo "</td>
                ";
            // line 48
            echo " 
                ";
            // line 49
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["translations"]) ? $context["translations"] : null));
            foreach ($context['_seq'] as $context["_key"] => $context["translation"]) {
                // line 50
                echo "                        <td>
                            ";
                // line 51
                if (($this->getAttribute($context["macrocategorieMag"], "locale", array()) == $this->getAttribute($context["translation"], "code", array()))) {
                    // line 52
                    echo "                                <a href=\"";
                    echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_macrocategorieMag_edit", array("id" => $this->getAttribute($context["macrocategorieMag"], "id", array()))), "html", null, true);
                    echo "\" class=\"btn btn-warning btn-xs\">";
                    echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("macrocategorieMag.edit"), "html", null, true);
                    echo "</a>
                            ";
                } else {
                    // line 54
                    echo "                                ";
                    $context["macrocategorieMag_translation"] = $this->env->getExtension('AppBundle\Twig\AppAdminExtension')->isMacrocategorieMagTranslation($this->getAttribute($context["macrocategorieMag"], "locale", array()), $this->getAttribute($context["translation"], "code", array()), $this->getAttribute($context["macrocategorieMag"], "id", array()));
                    // line 55
                    echo "        
                                ";
                    // line 56
                    if ((isset($context["macrocategorieMag_translation"]) ? $context["macrocategorieMag_translation"] : null)) {
                        // line 57
                        echo "                                    <a href=\"";
                        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_macrocategorieMag_translation_edit", array("idParent" => $this->getAttribute($context["macrocategorieMag"], "id", array()), "id" => $this->getAttribute((isset($context["macrocategorieMag_translation"]) ? $context["macrocategorieMag_translation"] : null), "id", array()), "localeMacrocategorieMag" => $this->getAttribute($context["macrocategorieMag"], "locale", array()), "localeTranslation" => $this->getAttribute($context["translation"], "code", array()))), "html", null, true);
                        echo "\" class=\"btn btn-warning btn-xs\">";
                        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("app.translation.edit"), "html", null, true);
                        echo "</a>
                                ";
                    } else {
                        // line 59
                        echo "                                    <a href=\"";
                        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_macrocategorieMag_translation_add", array("id" => $this->getAttribute($context["macrocategorieMag"], "id", array()), "localeMacrocategorieMag" => $this->getAttribute($context["macrocategorieMag"], "locale", array()), "localeTranslation" => $this->getAttribute($context["translation"], "code", array()))), "html", null, true);
                        echo "\" class=\"btn btn-info btn-xs\">";
                        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("app.translation.add"), "html", null, true);
                        echo "</a>
                                ";
                    }
                    // line 61
                    echo "                            ";
                }
                // line 62
                echo "                        </td>
                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['translation'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 64
            echo "

            </tr>
        ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['macrocategorieMag'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 68
        echo "        </tbody>
    </table>
\t<div class=\"navigation\">
\t\t";
        // line 71
        echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->render($this->env, (isset($context["categories"]) ? $context["categories"] : null));
        echo "
\t</div>
";
    }

    public function getTemplateName()
    {
        return "admin/macrocategorieMag/admin_macrocategorieMag_index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  216 => 71,  211 => 68,  194 => 64,  187 => 62,  184 => 61,  176 => 59,  168 => 57,  166 => 56,  163 => 55,  160 => 54,  152 => 52,  150 => 51,  147 => 50,  143 => 49,  140 => 48,  136 => 41,  132 => 40,  128 => 39,  125 => 38,  108 => 37,  103 => 34,  94 => 32,  90 => 31,  87 => 30,  83 => 27,  79 => 26,  66 => 18,  60 => 15,  55 => 12,  53 => 11,  47 => 8,  43 => 7,  40 => 6,  37 => 5,  29 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "admin/macrocategorieMag/admin_macrocategorieMag_index.html.twig", "C:\\wamp64\\www\\symfony\\jedy-develop\\app\\Resources\\views\\admin\\macrocategorieMag\\admin_macrocategorieMag_index.html.twig");
    }
}
