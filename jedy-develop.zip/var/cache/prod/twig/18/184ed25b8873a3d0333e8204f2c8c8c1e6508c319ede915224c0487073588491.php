<?php

/* admin/content/admin_content_index.html.twig */
class __TwigTemplate_aaf9ed4d2e83b42275b3c7d904acacb262c5c36a540da5609c58106ce219113a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate(":admin:base_admin.html.twig", "admin/content/admin_content_index.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return ":admin:base_admin.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        echo " ";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("content.title.plural"), "html", null, true);
        echo " ";
    }

    // line 5
    public function block_content($context, array $blocks = array())
    {
        // line 6
        echo "    <ul class=\"breadcrumb\">
        <li><a href=\"";
        // line 7
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_home");
        echo "\">Home</a></li>
        ";
        // line 8
        if ((isset($context["type"]) ? $context["type"] : null)) {
            // line 9
            echo "            <li><a href=\"";
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_content_home");
            echo "\">";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("content.title.plural"), "html", null, true);
            echo "</a></li>
            <li class=\"active\">";
            // line 10
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("content.title.singular"), "html", null, true);
            echo " ";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans(("content.type." . (isset($context["type"]) ? $context["type"] : null))), "html", null, true);
            echo "</li>
        ";
        } else {
            // line 12
            echo "            <li class=\"active\">";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("content.title.plural"), "html", null, true);
            echo "</li>
        ";
        }
        // line 14
        echo "
    </ul>

    ";
        // line 17
        $this->loadTemplate("admin/_flashbag.html.twig", "admin/content/admin_content_index.html.twig", 17)->display($context);
        // line 18
        echo "
    <div class=\"row margin-vertical-md\">
        <div class=\"col-md-8\">
            <h1 class=\"h-btn-line\">";
        // line 21
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("content.title.plural"), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans(("content.type." . ((array_key_exists("type", $context)) ? (_twig_default_filter((isset($context["type"]) ? $context["type"] : null), "all")) : ("all")))), "html", null, true);
        echo "</h1>
        </div>
        <div class=\"col-md-4 text-right\">
            <div class=\"btn-group\">
                <a href=\"#\" class=\"btn btn-primary btn-sm\">";
        // line 25
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("content.add"), "html", null, true);
        echo "</a>
                <a href=\"#\" class=\"btn btn-primary btn-sm dropdown-toggle\" data-toggle=\"dropdown\"><span class=\"caret\"></span></a>
                <ul class=\"dropdown-menu\">
                    <li><a href=\"";
        // line 28
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_content_new", array("type" => "page"));
        echo "\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("content.type.page"), "html", null, true);
        echo "</a></li>
                    <li><a href=\"";
        // line 29
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_content_new", array("type" => "post"));
        echo "\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("content.type.post"), "html", null, true);
        echo "</a></li>
                </ul>
            </div>
        </div>
    </div>

    <table class=\"table table-striped table-hover \">
        <thead>
        <tr>
            <th>#</th>
            <th>";
        // line 39
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("content.title"), "html", null, true);
        echo "</th>
            <th>";
        // line 40
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("category.title.singular"), "html", null, true);
        echo "</th>
            <th>";
        // line 41
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("content.type"), "html", null, true);
        echo "</th>
            <th>";
        // line 42
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("app.actions"), "html", null, true);
        echo "</th>
        </tr>
        </thead>
        <tbody>
        ";
        // line 46
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["contents"]) ? $context["contents"] : null));
        $context['loop'] = array(
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        );
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["content"]) {
            // line 47
            echo "            <tr>
                <td>";
            // line 48
            echo twig_escape_filter($this->env, $this->getAttribute($context["loop"], "index", array()), "html", null, true);
            echo "</td>
                <td>";
            // line 49
            echo twig_escape_filter($this->env, $this->getAttribute($context["content"], "title", array()), "html", null, true);
            echo "</td>
                <td>";
            // line 50
            echo twig_escape_filter($this->env, (($this->getAttribute($this->getAttribute($context["content"], "category", array(), "any", false, true), "name", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute($this->getAttribute($context["content"], "category", array(), "any", false, true), "name", array()), "-")) : ("-")), "html", null, true);
            echo "</td>
                <td><span class=\"label label-default\">";
            // line 51
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans(("content.type." . $this->getAttribute($context["content"], "type", array()))), "html", null, true);
            echo "</span></td>
                <td>
                    <a href=\"";
            // line 53
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_content_edit", array("id" => $this->getAttribute($context["content"], "id", array()))), "html", null, true);
            echo "\" class=\"btn btn-warning btn-xs\">";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("app.edit"), "html", null, true);
            echo "</a>
                    <a href=\"";
            // line 54
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_content_translations", array("id" => $this->getAttribute($context["content"], "id", array()))), "html", null, true);
            echo "\" class=\"btn btn-info btn-xs\">";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("app.translations"), "html", null, true);
            echo "</a>
                </td>
            </tr>
        ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['content'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 58
        echo "        </tbody>
    </table>

    <ul class=\"pager\">
        ";
        // line 62
        $context["prev"] = ((isset($context["page"]) ? $context["page"] : null) - 1);
        // line 63
        echo "
        ";
        // line 64
        if (((isset($context["prev"]) ? $context["prev"] : null) != 0)) {
            // line 65
            echo "            <li class=\"previous\"><a href=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_content_home", array("page" => (isset($context["prev"]) ? $context["prev"] : null))), "html", null, true);
            echo "\">&larr; ";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("app.pagination.older"), "html", null, true);
            echo "</a></li>
        ";
        } else {
            // line 67
            echo "            <li class=\"previous disabled\"><a href=\"\">&larr; ";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("app.pagination.older"), "html", null, true);
            echo "</a></li>
        ";
        }
        // line 69
        echo "
        ";
        // line 70
        if (((isset($context["totalPages"]) ? $context["totalPages"] : null) >= ((isset($context["page"]) ? $context["page"] : null) + 1))) {
            // line 71
            echo "            <li class=\"next\"><a href=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_content_home", array("page" => ((isset($context["page"]) ? $context["page"] : null) + 1))), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("app.pagination.newer"), "html", null, true);
            echo " &rarr;</a></li>
        ";
        } else {
            // line 73
            echo "            <li class=\"next disabled\"><a href=\"\">";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("app.pagination.newer"), "html", null, true);
            echo " &rarr;</a></li>
        ";
        }
        // line 75
        echo "    </ul>

";
    }

    public function getTemplateName()
    {
        return "admin/content/admin_content_index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  245 => 75,  239 => 73,  231 => 71,  229 => 70,  226 => 69,  220 => 67,  212 => 65,  210 => 64,  207 => 63,  205 => 62,  199 => 58,  179 => 54,  173 => 53,  168 => 51,  164 => 50,  160 => 49,  156 => 48,  153 => 47,  136 => 46,  129 => 42,  125 => 41,  121 => 40,  117 => 39,  102 => 29,  96 => 28,  90 => 25,  81 => 21,  76 => 18,  74 => 17,  69 => 14,  63 => 12,  56 => 10,  49 => 9,  47 => 8,  43 => 7,  40 => 6,  37 => 5,  29 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "admin/content/admin_content_index.html.twig", "C:\\wamp64\\www\\symfony\\jedy-develop\\app\\Resources\\views\\admin\\content\\admin_content_index.html.twig");
    }
}
