<?php

/* admin/macrocategorieMag/admin_macrocategorieMag_translations.html.twig */
class __TwigTemplate_9a861aa43e8622b8c97e5c9f4d6ef12215c128788e96d46447070509c3d3535d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate(":admin:base_admin.html.twig", "admin/macrocategorieMag/admin_macrocategorieMag_translations.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return ":admin:base_admin.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        echo " ";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("app.translations"), "html", null, true);
        echo " ";
    }

    // line 4
    public function block_content($context, array $blocks = array())
    {
        // line 5
        echo "
    <ul class=\"breadcrumb\">
        <li><a href=\"";
        // line 7
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_home");
        echo "\">Home</a></li>
        <li><a href=\"";
        // line 8
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_macrocategorieMag_home");
        echo "\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("macrocategorieMag.title.plural"), "html", null, true);
        echo "</a></li>
        <li><a href=\"";
        // line 9
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_macrocategorieMag_edit", array("id" => $this->getAttribute((isset($context["macrocategorieMag"]) ? $context["macrocategorieMag"] : null), "id", array()))), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["macrocategorieMag"]) ? $context["macrocategorieMag"] : null), "name", array()), "html", null, true);
        echo "</a></li>
        <li class=\"active\">";
        // line 10
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("app.translations"), "html", null, true);
        echo "</li>
    </ul>

    ";
        // line 13
        $this->loadTemplate("admin/_flashbag.html.twig", "admin/macrocategorieMag/admin_macrocategorieMag_translations.html.twig", 13)->display($context);
        // line 14
        echo "
    <div class=\"row margin-vertical-md\">
        <div class=\"col-md-12\">
            <h1 class=\"h-btn-line\">";
        // line 17
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("app.translations"), "html", null, true);
        echo "</h1>
        </div>
    </div>

    <table class=\"table table-striped table-hover \">
        <thead>
        <tr>
            <th>#</th>
            <th>";
        // line 25
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("app.language"), "html", null, true);
        echo "</th>
            <th>";
        // line 26
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("app.actions"), "html", null, true);
        echo "</th>
        </tr>
        </thead>
        <tbody>
        ";
        // line 30
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["translations"]) ? $context["translations"] : null));
        $context['loop'] = array(
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        );
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["translation"]) {
            // line 31
            echo "            <tr>
                <td>";
            // line 32
            echo twig_escape_filter($this->env, $this->getAttribute($context["loop"], "index", array()), "html", null, true);
            echo "</td>
                <td>";
            // line 33
            echo twig_escape_filter($this->env, $this->getAttribute($context["translation"], "name", array()), "html", null, true);
            echo "</td>
                <td>
                    ";
            // line 35
            if (($this->getAttribute((isset($context["macrocategorieMag"]) ? $context["macrocategorieMag"] : null), "locale", array()) == $this->getAttribute($context["translation"], "code", array()))) {
                // line 36
                echo "                        <a href=\"";
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_macrocategorieMag_edit", array("id" => $this->getAttribute((isset($context["macrocategorieMag"]) ? $context["macrocategorieMag"] : null), "id", array()))), "html", null, true);
                echo "\" class=\"btn btn-warning btn-xs\">";
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("macrocategorieMag.edit"), "html", null, true);
                echo "</a>
                    ";
            } else {
                // line 38
                echo "                        ";
                $context["macrocategorieMag_translation"] = $this->env->getExtension('AppBundle\Twig\AppAdminExtension')->isMacrocategorieMagTranslation($this->getAttribute((isset($context["macrocategorieMag"]) ? $context["macrocategorieMag"] : null), "locale", array()), $this->getAttribute($context["translation"], "code", array()), $this->getAttribute((isset($context["macrocategorieMag"]) ? $context["macrocategorieMag"] : null), "id", array()));
                // line 39
                echo "
                        ";
                // line 40
                if ((isset($context["macrocategorieMag_translation"]) ? $context["macrocategorieMag_translation"] : null)) {
                    // line 41
                    echo "                            <a href=\"";
                    echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_macrocategorieMag_translation_edit", array("idParent" => $this->getAttribute((isset($context["macrocategorieMag"]) ? $context["macrocategorieMag"] : null), "id", array()), "id" => $this->getAttribute((isset($context["macrocategorieMag_translation"]) ? $context["macrocategorieMag_translation"] : null), "id", array()), "localeMacrocategorieMag" => $this->getAttribute((isset($context["macrocategorieMag"]) ? $context["macrocategorieMag"] : null), "locale", array()), "localeTranslation" => $this->getAttribute($context["translation"], "code", array()))), "html", null, true);
                    echo "\" class=\"btn btn-warning btn-xs\">";
                    echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("app.translation.edit"), "html", null, true);
                    echo "</a>
                        ";
                } else {
                    // line 43
                    echo "                            <a href=\"";
                    echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_macrocategorieMag_translation_add", array("id" => $this->getAttribute((isset($context["macrocategorieMag"]) ? $context["macrocategorieMag"] : null), "id", array()), "localeMacrocategorieMag" => $this->getAttribute((isset($context["macrocategorieMag"]) ? $context["macrocategorieMag"] : null), "locale", array()), "localeTranslation" => $this->getAttribute($context["translation"], "code", array()))), "html", null, true);
                    echo "\" class=\"btn btn-info btn-xs\">";
                    echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("app.translation.add"), "html", null, true);
                    echo "</a>
                        ";
                }
                // line 45
                echo "                    ";
            }
            // line 46
            echo "                </td>
            </tr>
        ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['translation'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 49
        echo "        </tbody>
    </table>

";
    }

    public function getTemplateName()
    {
        return "admin/macrocategorieMag/admin_macrocategorieMag_translations.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  177 => 49,  161 => 46,  158 => 45,  150 => 43,  142 => 41,  140 => 40,  137 => 39,  134 => 38,  126 => 36,  124 => 35,  119 => 33,  115 => 32,  112 => 31,  95 => 30,  88 => 26,  84 => 25,  73 => 17,  68 => 14,  66 => 13,  60 => 10,  54 => 9,  48 => 8,  44 => 7,  40 => 5,  37 => 4,  29 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "admin/macrocategorieMag/admin_macrocategorieMag_translations.html.twig", "C:\\wamp64\\www\\symfony\\jedy-develop\\app\\Resources\\views\\admin\\macrocategorieMag\\admin_macrocategorieMag_translations.html.twig");
    }
}
