<?php

/* :admin:admin_home.html.twig */
class __TwigTemplate_97c28b7a129ee25709bfd017396172cf82e7200b4b0b74c8457146fcc8332165 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate(":admin:base_admin.html.twig", ":admin:admin_home.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return ":admin:base_admin.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        echo "Welcome!";
    }

    // line 5
    public function block_content($context, array $blocks = array())
    {
        // line 6
        echo "
    <div class=\"jumbotron\">
        <h1>";
        // line 8
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("app.welcome"), "html", null, true);
        echo "</h1>
        <p>";
        // line 9
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("app.description");
        echo "</p>
    </div>

    <div class=\"row\">
        <div class=\"col-sm-4\">
            <div class=\"panel panel-primary\">
                <div class=\"panel-heading\">
                    <h3 class=\"panel-title\">";
        // line 16
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("content.type.page"), "html", null, true);
        echo " <span class=\"badge\"><i class=\"fa fa-eye\"></i> ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["count"]) ? $context["count"] : null), "page", array()), "html", null, true);
        echo "</span></h3>
                </div>
                <div class=\"panel-body\">
                    ";
        // line 19
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("content.definition.page"), "html", null, true);
        echo "
                </div>
            </div>
        </div>
        <div class=\"col-sm-4\">
            <div class=\"panel panel-primary\">
                <div class=\"panel-heading\">
                    <h3 class=\"panel-title\">";
        // line 26
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("content.type.post"), "html", null, true);
        echo " <span class=\"badge\"><i class=\"fa fa-eye\"></i> ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["count"]) ? $context["count"] : null), "post", array()), "html", null, true);
        echo "</span></h3>
                </div>
                <div class=\"panel-body\">
                   ";
        // line 29
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("content.definition.post"), "html", null, true);
        echo "
                </div>
            </div>
        </div>
        <div class=\"col-sm-4\">
            <div class=\"panel panel-primary\">
                <div class=\"panel-heading\">
                    <h3 class=\"panel-title\">";
        // line 36
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("category.title.singular"), "html", null, true);
        echo " <span class=\"badge\"><i class=\"fa fa-eye\"></i> ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["count"]) ? $context["count"] : null), "category", array()), "html", null, true);
        echo "</span></h3>
                </div>
                <div class=\"panel-body\">
                    ";
        // line 39
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("category.definition"), "html", null, true);
        echo "
                </div>
            </div>
        </div>
    </div>
";
    }

    public function getTemplateName()
    {
        return ":admin:admin_home.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  100 => 39,  92 => 36,  82 => 29,  74 => 26,  64 => 19,  56 => 16,  46 => 9,  42 => 8,  38 => 6,  35 => 5,  29 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", ":admin:admin_home.html.twig", "C:\\wamp64\\www\\symfony\\jedy-develop\\app/Resources\\views/admin/admin_home.html.twig");
    }
}
