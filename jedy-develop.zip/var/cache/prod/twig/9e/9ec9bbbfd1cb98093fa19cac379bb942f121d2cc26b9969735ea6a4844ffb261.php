<?php

/* admin/file/admin_file_index.html.twig */
class __TwigTemplate_d57954268f8c49a54a0702c610b5afd05bf4421712cddb25b87f6f8433e37c36 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate(":admin:base_admin.html.twig", "admin/file/admin_file_index.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return ":admin:base_admin.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        echo " ";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("file.title.plural"), "html", null, true);
        echo " ";
    }

    // line 5
    public function block_content($context, array $blocks = array())
    {
        // line 6
        echo "    <ul class=\"breadcrumb\">
        <li><a href=\"";
        // line 7
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_home");
        echo "\">Home</a></li>
        <li class=\"active\">";
        // line 8
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("file.title.plural"), "html", null, true);
        echo "</li>
    </ul>

    ";
        // line 11
        $this->loadTemplate("admin/_flashbag.html.twig", "admin/file/admin_file_index.html.twig", 11)->display($context);
        // line 12
        echo "
    <div class=\"row margin-vertical-md\">
        <div class=\"col-md-8\">
            <h1 class=\"h-btn-line\">";
        // line 15
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("file.title.plural"), "html", null, true);
        echo "</h1>
        </div>
        <div class=\"col-md-4 text-right\">
            <a href=\"";
        // line 18
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_file_upload");
        echo "\" class=\"btn btn-primary btn-sm\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("file.add"), "html", null, true);
        echo "</a>
        </div>
    </div>

    <table class=\"table table-striped table-hover \">
        <thead>
        <tr>
            <th>#</th>
            <th>";
        // line 26
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("file.name"), "html", null, true);
        echo "</th>
            <th>";
        // line 27
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("file.view"), "html", null, true);
        echo "</th>
            <th>";
        // line 28
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("file.details"), "html", null, true);
        echo "</th>
            <th>";
        // line 29
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("app.actions"), "html", null, true);
        echo "</th>
        </tr>
        </thead>
        <tbody>
        ";
        // line 33
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["files"]) ? $context["files"] : null));
        $context['loop'] = array(
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        );
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 34
            echo "            <tr>
                <td>";
            // line 35
            echo twig_escape_filter($this->env, $this->getAttribute($context["loop"], "index", array()), "html", null, true);
            echo "</td>
                <td><span class=\"label label-info\">";
            // line 36
            echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "filename", array()), "html", null, true);
            echo "</span></td>
                <td>
                    ";
            // line 38
            echo $this->env->getExtension('AppBundle\Twig\AppAdminExtension')->render_file($this->getAttribute($context["item"], "filename", array()), $this->getAttribute($context["item"], "extension", array()));
            echo "
                </td>
                <td><i class=\"fa fa-clock-o\"></i> ";
            // line 40
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["item"], "cTime", array()), "d/m/Y H:I"), "html", null, true);
            echo "</td>
                <td class=\"text-right\">
                    <a class=\"btn btn-danger btn-md\" href=\"";
            // line 42
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_file_delete", array("filename" => $this->getAttribute($context["item"], "filename", array()))), "html", null, true);
            echo "\"> <i class=\"fa fa-trash\"></i> </a>
                </td>
            </tr>
        ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 46
        echo "        </tbody>
    </table>

    <ul class=\"pager\">
        ";
        // line 50
        $context["prev"] = ((isset($context["page"]) ? $context["page"] : null) - 1);
        // line 51
        echo "
        ";
        // line 52
        if (((isset($context["prev"]) ? $context["prev"] : null) != 0)) {
            // line 53
            echo "            <li class=\"previous\"><a href=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_file_home_page", array("page" => (isset($context["prev"]) ? $context["prev"] : null))), "html", null, true);
            echo "\">&larr; ";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("app.pagination.older"), "html", null, true);
            echo "</a></li>
        ";
        } else {
            // line 55
            echo "            <li class=\"previous disabled\"><a href=\"\">&larr; ";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("app.pagination.older"), "html", null, true);
            echo "</a></li>
        ";
        }
        // line 57
        echo "
        ";
        // line 58
        if (((isset($context["totalPages"]) ? $context["totalPages"] : null) >= ((isset($context["page"]) ? $context["page"] : null) + 1))) {
            // line 59
            echo "            <li class=\"next\"><a href=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_file_home_page", array("page" => ((isset($context["page"]) ? $context["page"] : null) + 1))), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("app.pagination.newer"), "html", null, true);
            echo " &rarr;</a></li>
        ";
        } else {
            // line 61
            echo "            <li class=\"next disabled\"><a href=\"\">";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("app.pagination.newer"), "html", null, true);
            echo " &rarr;</a></li>
        ";
        }
        // line 63
        echo "    </ul>
";
    }

    public function getTemplateName()
    {
        return "admin/file/admin_file_index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  201 => 63,  195 => 61,  187 => 59,  185 => 58,  182 => 57,  176 => 55,  168 => 53,  166 => 52,  163 => 51,  161 => 50,  155 => 46,  137 => 42,  132 => 40,  127 => 38,  122 => 36,  118 => 35,  115 => 34,  98 => 33,  91 => 29,  87 => 28,  83 => 27,  79 => 26,  66 => 18,  60 => 15,  55 => 12,  53 => 11,  47 => 8,  43 => 7,  40 => 6,  37 => 5,  29 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "admin/file/admin_file_index.html.twig", "C:\\wamp64\\www\\symfony\\jedy-develop\\app\\Resources\\views\\admin\\file\\admin_file_index.html.twig");
    }
}
