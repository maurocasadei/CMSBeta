<?php

/* :public:base_public.html.twig */
class __TwigTemplate_05cba70feef396345c7343b59cfbcb03f1a945d9d12303c4716ff6215a0540ac extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("::base.html.twig", ":public:base_public.html.twig", 1);
        $this->blocks = array(
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'content' => array($this, 'block_content'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_stylesheets($context, array $blocks = array())
    {
        // line 4
        echo "    <link href=\"https://maxcdn.bootstrapcdn.com/bootswatch/3.3.6/flatly/bootstrap.min.css\" rel=\"stylesheet\" integrity=\"sha256-Av2lUNJFz7FqxLquvIFyxyCQA/VHUFna3onVy+5jUBM= sha512-zyqATyziDoUzMiMR8EAD3c5Ye55I2V3K7GcmJDHbL49cXzFQCEA6flSKqxEzwxXqq73/M4A0jKFFJ/ysEhbExQ==\" crossorigin=\"anonymous\">
    <link rel=\"stylesheet\" href=\"";
        // line 5
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/style-public.css"), "html", null, true);
        echo "\">
    <link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css\">
";
    }

    // line 9
    public function block_body($context, array $blocks = array())
    {
        // line 10
        echo "
    <!-- Fixed navbar -->
    <nav class=\"navbar navbar-default navbar-fixed-top\">
        <div class=\"container\">
            <div class=\"navbar-header\">
                <button type=\"button\" class=\"navbar-toggle collapsed\" data-toggle=\"collapse\" data-target=\"#navbar\" aria-expanded=\"false\" aria-controls=\"navbar\">
                    <span class=\"sr-only\">Toggle navigation</span>
                    <span class=\"icon-bar\"></span>
                    <span class=\"icon-bar\"></span>
                    <span class=\"icon-bar\"></span>
                </button>
                <a class=\"navbar-brand\" href=\"";
        // line 21
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_index");
        echo "\">Jedy CMS</a>
            </div>
            <div id=\"navbar\" class=\"navbar-collapse collapse\">
                <ul class=\"nav navbar-nav\">
                    <li class=\"active\"><a href=\"";
        // line 25
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_index");
        echo "\">Home</a></li>
                    <li><a href=\"";
        // line 26
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_blog_index");
        echo "\">Blog</a></li>
                </ul>

                ";
        // line 29
        echo $this->env->getExtension('AppBundle\Twig\AppPublicExtension')->nav_locale("principal", $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "request", array()), "locale", array()));
        echo "

                <ul class=\"nav navbar-nav navbar-right\">
                    <li class=\"dropdown\">
                        <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\" role=\"button\" aria-haspopup=\"true\" aria-expanded=\"false\">";
        // line 33
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("app.about"), "html", null, true);
        echo " <span class=\"caret\"></span></a>
                        <ul class=\"dropdown-menu\">
                            <li><a href=\"https://github.com/JuanLuisGarciaBorrego/jedy\" target=\"_new\"><i class=\"fa fa-github\"></i> ";
        // line 35
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("app.github"), "html", null, true);
        echo "</a></li>
                            <li><a href=\"http://juanluisgarciaborrego.com/\" target=\"_new\"><i class=\"fa fa-user\"></i> ";
        // line 36
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("app.website"), "html", null, true);
        echo "</a></li>
                            <li role=\"separator\" class=\"divider\"></li>
                            <li class=\"dropdown-header\"><i class=\"fa fa-key\"></i> ";
        // line 38
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("app.private"), "html", null, true);
        echo "</li>
                            <li><a href=\"";
        // line 39
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_home");
        echo "\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("app.administration"), "html", null, true);
        echo "</a></li>
                        </ul>
                    </li>
                    <li class=\"dropdown\">
                        <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\" role=\"button\" aria-haspopup=\"true\" aria-expanded=\"false\">";
        // line 43
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("app.language"), "html", null, true);
        echo " <span class=\"caret\"></span></a>
                        <ul class=\"dropdown-menu\">
                            ";
        // line 45
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["locales"]) ? $context["locales"] : null), "getLocales", array(0 => true), "method"));
        foreach ($context['_seq'] as $context["_key"] => $context["locale"]) {
            // line 46
            echo "                                <li><a href=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_index", array("_locale" => $this->getAttribute($context["locale"], "code", array()))), "html", null, true);
            echo "\">
                                    ";
            // line 47
            if (($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "request", array()), "locale", array()) == $this->getAttribute($context["locale"], "code", array()))) {
                // line 48
                echo "                                        <i class=\"fa fa-language\"></i>
                                    ";
            }
            // line 50
            echo "                                    ";
            echo twig_escape_filter($this->env, $this->getAttribute($context["locale"], "name", array()), "html", null, true);
            echo "
                                </a></li>
                            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['locale'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 53
        echo "                        </ul>
                    </li>
                </ul>

            </div><!--/.nav-collapse -->
        </div>
    </nav>

    <div class=\"container\">
        ";
        // line 62
        $this->displayBlock('content', $context, $blocks);
        // line 65
        echo "
        <footer>
            <div class=\"well text-center\">
                <div>
                    <i class=\"fa fa-star\"></i> Jedy CMS Multi-language<br>
                    Created by <a href=\"https://twitter.com/JuanluGarciaB\" target=\"_new\"> Juan Luis García Borrego </a>
                </div>
                <div>
                    <p>
                        <a href=\"https://github.com/JuanLuisGarciaBorrego/jedy\" target=\"new\">Github Project</a>
                        <span class=\"hide-xs\">·</span>
                        <a href=\"https://github.com/JuanLuisGarciaBorrego/jedy/issues\" target=\"_new\">Issues</a>
                    </p>
                </div>
            </div>
        </footer>

    </div> <!-- /container -->
";
    }

    // line 62
    public function block_content($context, array $blocks = array())
    {
        // line 63
        echo "
        ";
    }

    // line 85
    public function block_javascripts($context, array $blocks = array())
    {
        // line 86
        echo "
    ";
        // line 87
        $this->displayParentBlock("javascripts", $context, $blocks);
        echo "

    <script src=\"https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js\"></script>
    <script src=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js\"></script>
";
    }

    public function getTemplateName()
    {
        return ":public:base_public.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  190 => 87,  187 => 86,  184 => 85,  179 => 63,  176 => 62,  154 => 65,  152 => 62,  141 => 53,  131 => 50,  127 => 48,  125 => 47,  120 => 46,  116 => 45,  111 => 43,  102 => 39,  98 => 38,  93 => 36,  89 => 35,  84 => 33,  77 => 29,  71 => 26,  67 => 25,  60 => 21,  47 => 10,  44 => 9,  37 => 5,  34 => 4,  31 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", ":public:base_public.html.twig", "C:\\wamp64\\www\\symfony\\jedy-develop\\app/Resources\\views/public/base_public.html.twig");
    }
}
