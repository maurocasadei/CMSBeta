<?php

/* public/blog/blog_category.html.twig */
class __TwigTemplate_8d3d196639e83f31b570e5948e25a7969957490f319e417dcf4ee0d192346b31 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("public/base_public.html.twig", "public/blog/blog_category.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "public/base_public.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        echo " ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["category"]) ? $context["category"] : null), "name", array()), "html", null, true);
        echo " ";
    }

    // line 5
    public function block_content($context, array $blocks = array())
    {
        // line 6
        echo "
    <div class=\"jumbotron\">
        <h1>";
        // line 8
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["category"]) ? $context["category"] : null), "name", array()), "html", null, true);
        echo "</h1>
        <p>";
        // line 9
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["category"]) ? $context["category"] : null), "description", array()), "html", null, true);
        echo ".</p>
    </div>

    <div class=\"row\">
        ";
        // line 13
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["posts"]) ? $context["posts"] : null));
        foreach ($context['_seq'] as $context["_key"] => $context["post"]) {
            // line 14
            echo "            <div class=\"col-xs-12\">
                <h2>";
            // line 15
            echo twig_escape_filter($this->env, $this->getAttribute($context["post"], "title", array()), "html", null, true);
            echo "</h2>
                <p>";
            // line 16
            echo twig_escape_filter($this->env, $this->getAttribute($context["post"], "summary", array()), "html", null, true);
            echo "</p>
                <span>";
            // line 17
            echo twig_escape_filter($this->env, twig_localized_date_filter($this->env, $this->getAttribute($context["post"], "publishedAt", array()), "medium", "short"), "html", null, true);
            echo "</span>
                <p><a class=\"btn btn-default\" href=\"";
            // line 18
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_blog_post", array("_locale" => $this->getAttribute($context["post"], "locale", array()), "slugcategory" => $this->getAttribute($this->getAttribute($context["post"], "category", array()), "slug", array()), "slug" => $this->getAttribute($context["post"], "slug", array()))), "html", null, true);
            echo "\" role=\"button\">";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("app.read.more"), "html", null, true);
            echo " &raquo;</a></p>
            </div>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['post'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 21
        echo "    </div>

    <ul class=\"pager\">
        ";
        // line 24
        $context["prev"] = ((isset($context["page"]) ? $context["page"] : null) - 1);
        // line 25
        echo "
        ";
        // line 26
        if (((isset($context["prev"]) ? $context["prev"] : null) != 0)) {
            // line 27
            echo "            <li class=\"previous\"><a href=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_blog_category_paginated", array("slug" => $this->getAttribute((isset($context["category"]) ? $context["category"] : null), "slug", array()), "page" => (isset($context["prev"]) ? $context["prev"] : null))), "html", null, true);
            echo "\">&larr; Older</a></li>
        ";
        } else {
            // line 29
            echo "            <li class=\"previous disabled\"><a href=\"\">&larr; Older</a></li>
        ";
        }
        // line 31
        echo "
        ";
        // line 32
        if (((isset($context["totalPages"]) ? $context["totalPages"] : null) >= ((isset($context["page"]) ? $context["page"] : null) + 1))) {
            // line 33
            echo "            <li class=\"next\"><a href=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_blog_category_paginated", array("slug" => $this->getAttribute((isset($context["category"]) ? $context["category"] : null), "slug", array()), "page" => ((isset($context["page"]) ? $context["page"] : null) + 1))), "html", null, true);
            echo "\">Newer &rarr;</a></li>
        ";
        } else {
            // line 35
            echo "            <li class=\"next disabled\"><a href=\"\">Newer &rarr;</a></li>
        ";
        }
        // line 37
        echo "    </ul>

";
    }

    public function getTemplateName()
    {
        return "public/blog/blog_category.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  122 => 37,  118 => 35,  112 => 33,  110 => 32,  107 => 31,  103 => 29,  97 => 27,  95 => 26,  92 => 25,  90 => 24,  85 => 21,  74 => 18,  70 => 17,  66 => 16,  62 => 15,  59 => 14,  55 => 13,  48 => 9,  44 => 8,  40 => 6,  37 => 5,  29 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "public/blog/blog_category.html.twig", "C:\\wamp64\\www\\symfony\\jedy-develop\\app\\Resources\\views\\public\\blog\\blog_category.html.twig");
    }
}
