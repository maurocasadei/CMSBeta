<?php

/* generic/generic.html.twig */
class __TwigTemplate_26fd8e8003e908d7b474d4fd014e054952bcaa0337a7a9b91444b481ff7fb882 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "
<h1>Your lucky number is  dddd ";
        // line 2
        echo twig_escape_filter($this->env, (isset($context["number"]) ? $context["number"] : null), "html", null, true);
        echo "</h1>

";
    }

    public function getTemplateName()
    {
        return "generic/generic.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  22 => 2,  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "generic/generic.html.twig", "C:\\wamp64\\www\\symfony\\jedy-develop\\app\\Resources\\views\\generic\\generic.html.twig");
    }
}
