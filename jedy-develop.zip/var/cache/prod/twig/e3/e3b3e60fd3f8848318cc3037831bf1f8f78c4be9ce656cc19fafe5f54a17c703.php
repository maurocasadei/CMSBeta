<?php

/* :admin/nav:admin_nav_new.html.twig */
class __TwigTemplate_edb1760fa4bcee467494a11a407c529c0ca86ead3227e9181fece1dc1e88bac1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate(":admin:base_admin.html.twig", ":admin/nav:admin_nav_new.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return ":admin:base_admin.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        echo " ";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("nav.add"), "html", null, true);
        echo " ";
    }

    // line 5
    public function block_content($context, array $blocks = array())
    {
        // line 6
        echo "    <ul class=\"breadcrumb\">
        <li><a href=\"";
        // line 7
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_home");
        echo "\">Home</a></li>
        <li><a href=\"";
        // line 8
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_nav_home");
        echo "\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("nav.title.plural"), "html", null, true);
        echo "</a></li>
        <li class=\"active\">";
        // line 9
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("nav.add"), "html", null, true);
        echo "</li>
    </ul>

    <div class=\"row margin-vertical-md\">
        <div class=\"col-md-12\">
            <h1 class=\"h-btn-line\">
                ";
        // line 15
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("nav.add"), "html", null, true);
        echo "
            </h1>
        </div>
    </div>

    <div class=\"row margin-vertical-md\">
        <div class=\"col-md-5\">

            <div class=\"panel panel-default\">
                <div class=\"panel-body\">

                    ";
        // line 26
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form_category"]) ? $context["form_category"] : null), 'form_start');
        echo "
                        ";
        // line 27
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["form_category"]) ? $context["form_category"] : null), 'widget');
        echo "
                        <button type=\"submit\" class=\"btn btn-primary btn-xs btn-block\"> ";
        // line 28
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("category.add"), "html", null, true);
        echo "</button>
                    ";
        // line 29
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form_category"]) ? $context["form_category"] : null), 'form_end');
        echo "

                    ";
        // line 31
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form_page"]) ? $context["form_page"] : null), 'form_start');
        echo "
                        ";
        // line 32
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["form_page"]) ? $context["form_page"] : null), 'widget');
        echo "
                        <button type=\"submit\" class=\"btn btn-primary btn-xs btn-block\"> ";
        // line 33
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("content.add"), "html", null, true);
        echo "</button>
                    ";
        // line 34
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form_page"]) ? $context["form_page"] : null), 'form_end');
        echo "

                </div>
            </div>

        </div>
        <div class=\"col-md-6 col-md-offset-1\">

            ";
        // line 42
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "session", array()), "flashbag", array()), "get", array(0 => "error"), "method"));
        foreach ($context['_seq'] as $context["_key"] => $context["flash_message"]) {
            // line 43
            echo "                <div class=\"alert alert-dismissible alert-warning\">
                    <button type=\"button\" class=\"close\" data-dismiss=\"alert\">x</button>
                    <strong><i class=\"fa fa-exclamation-triangle\"></i></strong> ";
            // line 45
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans($context["flash_message"]), "html", null, true);
            echo "
                </div>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['flash_message'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 48
        echo "
            ";
        // line 49
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["formNavContents"]) ? $context["formNavContents"] : null), 'form_start');
        echo "
                <table class=\"table table-striped table-hover \">
                    <thead>
                        <tr>
                            <th colspan=\"5\" class=\"success\">";
        // line 53
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("nav.id"), "html", null, true);
        echo "</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td colspan=\"5\">";
        // line 58
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["formNavContents"]) ? $context["formNavContents"] : null), "name", array()), 'row');
        echo "</td>
                        </tr>
                        <tr class=\"success\">
                            <td colspan=\"5\">";
        // line 61
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("content.title.plural"), "html", null, true);
        echo "</td>
                        </tr>
                        <tr>
                            <th>#</th>
                            <th>";
        // line 65
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("nav.name"), "html", null, true);
        echo "</th>
                            <th>";
        // line 66
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("nav.parent"), "html", null, true);
        echo "</th>
                            <th>";
        // line 67
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("nav.sort"), "html", null, true);
        echo "</th>
                            <th>";
        // line 68
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("app.actions"), "html", null, true);
        echo "</th>
                        </tr>
                        ";
        // line 70
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["formNavContents"]) ? $context["formNavContents"] : null), "contentsNav", array()));
        $context['_iterated'] = false;
        $context['loop'] = array(
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        );
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["content"]) {
            // line 71
            echo "                            <tr>
                                <td>";
            // line 72
            echo twig_escape_filter($this->env, $this->getAttribute($context["loop"], "index", array()), "html", null, true);
            echo "</td>
                                <td>";
            // line 73
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute($context["content"], "vars", array()), "value", array()), "name", array()), "html", null, true);
            echo "</td>
                                <td>";
            // line 74
            echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($context["content"], "parent", array()), 'row');
            echo "</td>
                                <td>";
            // line 75
            echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($context["content"], "sort", array()), 'row');
            echo "</td>
                                <td><a href=\"";
            // line 76
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_nav_new_remove_element", array("idRemove" => $this->getAttribute($this->getAttribute($this->getAttribute($context["content"], "vars", array()), "value", array()), "idElement", array()))), "html", null, true);
            echo "\"
                                       class=\"btn btn-danger btn-md btn-block\"><i class=\"fa fa-trash\"></i></a>
                                </td>
                            </tr>
                        ";
            $context['_iterated'] = true;
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        if (!$context['_iterated']) {
            // line 81
            echo "                            <tr class=\"active\">
                                <td colspan=\"5\">";
            // line 82
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("nav.there.not"), "html", null, true);
            echo "</td>
                            </tr>
                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['content'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 85
        echo "                        <tr class=\"active\">
                            <td colspan=\"5\">
                                <button type=\"submit\" class=\"btn btn-primary btn-xs btn-block\"> ";
        // line 87
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("nav.add"), "html", null, true);
        echo "</button>
                            </td>
                        </tr>
                    </tbody>
                </table>
            ";
        // line 92
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["formNavContents"]) ? $context["formNavContents"] : null), 'form_end');
        echo "
            
        </div>
    </div>

";
    }

    public function getTemplateName()
    {
        return ":admin/nav:admin_nav_new.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  260 => 92,  252 => 87,  248 => 85,  239 => 82,  236 => 81,  218 => 76,  214 => 75,  210 => 74,  206 => 73,  202 => 72,  199 => 71,  181 => 70,  176 => 68,  172 => 67,  168 => 66,  164 => 65,  157 => 61,  151 => 58,  143 => 53,  136 => 49,  133 => 48,  124 => 45,  120 => 43,  116 => 42,  105 => 34,  101 => 33,  97 => 32,  93 => 31,  88 => 29,  84 => 28,  80 => 27,  76 => 26,  62 => 15,  53 => 9,  47 => 8,  43 => 7,  40 => 6,  37 => 5,  29 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", ":admin/nav:admin_nav_new.html.twig", "C:\\wamp64\\www\\symfony\\jedy-develop\\app/Resources\\views/admin/nav/admin_nav_new.html.twig");
    }
}
