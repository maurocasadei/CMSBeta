<?php

/* admin/category/admin_category_translations.html.twig */
class __TwigTemplate_291a839f1bed8013ad36e8dadc04c789893d6fa06977f05c8cf2124ddb111ddb extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate(":admin:base_admin.html.twig", "admin/category/admin_category_translations.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return ":admin:base_admin.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        echo " ";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("app.translations"), "html", null, true);
        echo " ";
    }

    // line 5
    public function block_content($context, array $blocks = array())
    {
        // line 6
        echo "
    <ul class=\"breadcrumb\">
        <li><a href=\"";
        // line 8
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_home");
        echo "\">Home</a></li>
        <li><a href=\"";
        // line 9
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_category_home");
        echo "\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("category.title.plural"), "html", null, true);
        echo "</a></li>
        <li><a href=\"";
        // line 10
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_category_edit", array("id" => $this->getAttribute((isset($context["category"]) ? $context["category"] : null), "id", array()))), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["category"]) ? $context["category"] : null), "name", array()), "html", null, true);
        echo "</a></li>
        <li class=\"active\">";
        // line 11
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("app.translations"), "html", null, true);
        echo "</li>
    </ul>

    ";
        // line 14
        $this->loadTemplate("admin/_flashbag.html.twig", "admin/category/admin_category_translations.html.twig", 14)->display($context);
        // line 15
        echo "
    <div class=\"row margin-vertical-md\">
        <div class=\"col-md-12\">
            <h1 class=\"h-btn-line\">";
        // line 18
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("app.translations"), "html", null, true);
        echo "</h1>
        </div>
    </div>

    <table class=\"table table-striped table-hover \">
        <thead>
        <tr>
            <th>#</th>
            <th>";
        // line 26
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("app.language"), "html", null, true);
        echo "</th>
            <th>";
        // line 27
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("app.actions"), "html", null, true);
        echo "</th>
        </tr>
        </thead>
        <tbody>
        ";
        // line 31
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["translations"]) ? $context["translations"] : null));
        $context['loop'] = array(
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        );
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["translation"]) {
            // line 32
            echo "            <tr>
                <td>";
            // line 33
            echo twig_escape_filter($this->env, $this->getAttribute($context["loop"], "index", array()), "html", null, true);
            echo "</td>
                <td>";
            // line 34
            echo twig_escape_filter($this->env, $this->getAttribute($context["translation"], "name", array()), "html", null, true);
            echo "</td>
                <td>
                    ";
            // line 36
            if (($this->getAttribute((isset($context["category"]) ? $context["category"] : null), "locale", array()) == $this->getAttribute($context["translation"], "code", array()))) {
                // line 37
                echo "                        <a href=\"";
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_category_edit", array("id" => $this->getAttribute((isset($context["category"]) ? $context["category"] : null), "id", array()))), "html", null, true);
                echo "\" class=\"btn btn-warning btn-xs\">";
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("category.edit"), "html", null, true);
                echo "</a>
                    ";
            } else {
                // line 39
                echo "                        ";
                $context["category_translation"] = $this->env->getExtension('AppBundle\Twig\AppAdminExtension')->isCategoryTranslation($this->getAttribute((isset($context["category"]) ? $context["category"] : null), "locale", array()), $this->getAttribute($context["translation"], "code", array()), $this->getAttribute((isset($context["category"]) ? $context["category"] : null), "id", array()));
                // line 40
                echo "
                        ";
                // line 41
                if ((isset($context["category_translation"]) ? $context["category_translation"] : null)) {
                    // line 42
                    echo "                            <a href=\"";
                    echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_category_translation_edit", array("idParent" => $this->getAttribute((isset($context["category"]) ? $context["category"] : null), "id", array()), "id" => $this->getAttribute((isset($context["category_translation"]) ? $context["category_translation"] : null), "id", array()), "localeCategory" => $this->getAttribute((isset($context["category"]) ? $context["category"] : null), "locale", array()), "localeTranslation" => $this->getAttribute($context["translation"], "code", array()))), "html", null, true);
                    echo "\" class=\"btn btn-warning btn-xs\">";
                    echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("app.translation.edit"), "html", null, true);
                    echo "</a>
                        ";
                } else {
                    // line 44
                    echo "                            <a href=\"";
                    echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_category_translation_add", array("id" => $this->getAttribute((isset($context["category"]) ? $context["category"] : null), "id", array()), "localeCategory" => $this->getAttribute((isset($context["category"]) ? $context["category"] : null), "locale", array()), "localeTranslation" => $this->getAttribute($context["translation"], "code", array()))), "html", null, true);
                    echo "\" class=\"btn btn-info btn-xs\">";
                    echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("app.translation.add"), "html", null, true);
                    echo "</a>
                        ";
                }
                // line 46
                echo "                    ";
            }
            // line 47
            echo "                </td>
            </tr>
        ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['translation'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 50
        echo "        </tbody>
    </table>

";
    }

    public function getTemplateName()
    {
        return "admin/category/admin_category_translations.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  177 => 50,  161 => 47,  158 => 46,  150 => 44,  142 => 42,  140 => 41,  137 => 40,  134 => 39,  126 => 37,  124 => 36,  119 => 34,  115 => 33,  112 => 32,  95 => 31,  88 => 27,  84 => 26,  73 => 18,  68 => 15,  66 => 14,  60 => 11,  54 => 10,  48 => 9,  44 => 8,  40 => 6,  37 => 5,  29 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "admin/category/admin_category_translations.html.twig", "C:\\wamp64\\www\\symfony\\jedy-develop\\app\\Resources\\views\\admin\\category\\admin_category_translations.html.twig");
    }
}
