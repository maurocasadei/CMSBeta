<?php

/* :admin/macrocategorieMag:admin_macrocategorieMag_edit.html.twig */
class __TwigTemplate_b749206167b2688eb5cb78ed33c5564bba4bb76c0ecc688ce1a4136bf47e220a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate(":admin:base_admin.html.twig", ":admin/macrocategorieMag:admin_macrocategorieMag_edit.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return ":admin:base_admin.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        echo " ";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("macrocategorieMag.edit"), "html", null, true);
        echo " ";
    }

    // line 5
    public function block_content($context, array $blocks = array())
    {
        // line 6
        echo "    <ul class=\"breadcrumb\">
        <li><a href=\"";
        // line 7
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_home");
        echo "\">Home</a></li>
        <li><a href=\"";
        // line 8
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_macrocategorieMag_home");
        echo "\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("macrocategorieMag.title.plural"), "html", null, true);
        echo "</a></li>
        ";
        // line 9
        if ($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "vars", array()), "value", array()), "parentMultilangue", array())) {
            // line 10
            echo "            <li><a href=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_macrocategorieMag_edit", array("id" => $this->getAttribute($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "vars", array()), "value", array()), "parentMultilangue", array()), "id", array()))), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "vars", array()), "value", array()), "parentMultilangue", array()), "name", array()), "html", null, true);
            echo "</a></li>
            <li><a href=\"";
            // line 11
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_macrocategorieMag_translations", array("id" => $this->getAttribute($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "vars", array()), "value", array()), "parentMultilangue", array()), "id", array()))), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("app.translation"), "html", null, true);
            echo "</a></li>
        ";
        }
        // line 13
        echo "        <li class=\"active\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("macrocategorieMag.edit"), "html", null, true);
        echo "</i></li>
    </ul>

    ";
        // line 16
        $this->loadTemplate("admin/_flashbag.html.twig", ":admin/macrocategorieMag:admin_macrocategorieMag_edit.html.twig", 16)->display($context);
        // line 17
        echo "    <div class=\"row margin-vertical-md\">
        <div class=\"col-xs-8\">
            <h1 class=\"h-btn-line\">";
        // line 19
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("macrocategorieMag.edit"), "html", null, true);
        echo "</h1>
        </div>

        <div class=\"col-xs-4\">
            ";
        // line 23
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form_delete"]) ? $context["form_delete"] : null), 'form_start');
        echo "
                ";
        // line 24
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["form_delete"]) ? $context["form_delete"] : null), 'widget');
        echo "
                <button class=\"btn btn-block btn-danger\" type=\"submit\">";
        // line 25
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("app.delete"), "html", null, true);
        echo "</button>
            ";
        // line 26
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form_delete"]) ? $context["form_delete"] : null), 'form_end');
        echo "
        </div>
    </div>

    ";
        // line 30
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : null), 'form_start');
        echo "
        ";
        // line 31
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : null), 'widget');
        echo "
        <button type=\"submit\" class=\"btn btn-primary\">";
        // line 32
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("macrocategorieMag.edit"), "html", null, true);
        echo "</button>
    ";
        // line 33
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : null), 'form_end');
        echo "
";
    }

    public function getTemplateName()
    {
        return ":admin/macrocategorieMag:admin_macrocategorieMag_edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  120 => 33,  116 => 32,  112 => 31,  108 => 30,  101 => 26,  97 => 25,  93 => 24,  89 => 23,  82 => 19,  78 => 17,  76 => 16,  69 => 13,  62 => 11,  55 => 10,  53 => 9,  47 => 8,  43 => 7,  40 => 6,  37 => 5,  29 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", ":admin/macrocategorieMag:admin_macrocategorieMag_edit.html.twig", "C:\\wamp64\\www\\symfony\\jedy-develop\\app/Resources\\views/admin/macrocategorieMag/admin_macrocategorieMag_edit.html.twig");
    }
}
