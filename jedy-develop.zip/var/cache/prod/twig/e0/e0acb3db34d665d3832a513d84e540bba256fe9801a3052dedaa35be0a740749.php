<?php

/* public/app/app_index.html.twig */
class __TwigTemplate_67f9f768eff5b962d90becee504e5a292d4b03cceb38913a2004116bfa41c1e9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("public/base_public.html.twig", "public/app/app_index.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "public/base_public.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        echo "Welcome!";
    }

    // line 5
    public function block_content($context, array $blocks = array())
    {
        // line 6
        echo "
    <div class=\"jumbotron text-center\">
        <h1>";
        // line 8
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("app.welcome"), "html", null, true);
        echo "</h1>
        <p>";
        // line 9
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("app.description");
        echo "</p>
        <p><a href=\"https://github.com/JuanLuisGarciaBorrego/jedy\" target=\"_new\" class=\"btn btn-primary btn-lg\"><i class=\"fa fa-github\"></i> ";
        // line 10
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("app.view.project"), "html", null, true);
        echo "</a></p>
    </div>

    <div class=\"row\">
    </div>

";
    }

    public function getTemplateName()
    {
        return "public/app/app_index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  50 => 10,  46 => 9,  42 => 8,  38 => 6,  35 => 5,  29 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "public/app/app_index.html.twig", "C:\\wamp64\\www\\symfony\\jedy-develop\\app\\Resources\\views\\public\\app\\app_index.html.twig");
    }
}
