<?php

use Symfony\Component\Routing\Exception\MethodNotAllowedException;
use Symfony\Component\Routing\Exception\ResourceNotFoundException;
use Symfony\Component\Routing\RequestContext;

/**
 * appProdUrlMatcher.
 *
 * This class has been auto-generated
 * by the Symfony Routing Component.
 */
class appProdUrlMatcher extends Symfony\Bundle\FrameworkBundle\Routing\RedirectableUrlMatcher
{
    /**
     * Constructor.
     */
    public function __construct(RequestContext $context)
    {
        $this->context = $context;
    }

    public function match($pathinfo)
    {
        $allow = array();
        $pathinfo = rawurldecode($pathinfo);
        $context = $this->context;
        $request = $this->request;

        // admin_home
        if (preg_match('#^/(?P<_locale>it|en|fr|de|ru|es)/admin/?$#s', $pathinfo, $matches)) {
            if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                $allow = array_merge($allow, array('GET', 'HEAD'));
                goto not_admin_home;
            }

            if (substr($pathinfo, -1) !== '/') {
                return $this->redirect($pathinfo.'/', 'admin_home');
            }

            return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_home')), array (  '_controller' => 'AppBundle\\Controller\\Admin\\AdminController::indexAction',  '_locale' => 'it',));
        }
        not_admin_home:

        // admin_category_home
        if (preg_match('#^/(?P<_locale>it|en|fr|de|ru|es)/admin/categories/?$#s', $pathinfo, $matches)) {
            if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                $allow = array_merge($allow, array('GET', 'HEAD'));
                goto not_admin_category_home;
            }

            if (substr($pathinfo, -1) !== '/') {
                return $this->redirect($pathinfo.'/', 'admin_category_home');
            }

            return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_category_home')), array (  '_controller' => 'AppBundle\\Controller\\Admin\\CategoryController::indexAction',  '_locale' => 'it',));
        }
        not_admin_category_home:

        // admin_category_new
        if (preg_match('#^/(?P<_locale>it|en|fr|de|ru|es)/admin/category/new/?$#s', $pathinfo, $matches)) {
            if (!in_array($this->context->getMethod(), array('GET', 'POST', 'HEAD'))) {
                $allow = array_merge($allow, array('GET', 'POST', 'HEAD'));
                goto not_admin_category_new;
            }

            if (substr($pathinfo, -1) !== '/') {
                return $this->redirect($pathinfo.'/', 'admin_category_new');
            }

            return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_category_new')), array (  '_controller' => 'AppBundle\\Controller\\Admin\\CategoryController::newAction',  '_locale' => 'it',));
        }
        not_admin_category_new:

        // admin_category_edit
        if (preg_match('#^/(?P<_locale>it|en|fr|de|ru|es)/admin/category/(?P<id>[^/]++)/edit/?$#s', $pathinfo, $matches)) {
            if (!in_array($this->context->getMethod(), array('GET', 'POST', 'HEAD'))) {
                $allow = array_merge($allow, array('GET', 'POST', 'HEAD'));
                goto not_admin_category_edit;
            }

            if (substr($pathinfo, -1) !== '/') {
                return $this->redirect($pathinfo.'/', 'admin_category_edit');
            }

            return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_category_edit')), array (  '_controller' => 'AppBundle\\Controller\\Admin\\CategoryController::editAction',  '_locale' => 'it',));
        }
        not_admin_category_edit:

        // admin_category_translations
        if (preg_match('#^/(?P<_locale>it|en|fr|de|ru|es)/admin/category/(?P<id>[^/]++)/translations/?$#s', $pathinfo, $matches)) {
            if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                $allow = array_merge($allow, array('GET', 'HEAD'));
                goto not_admin_category_translations;
            }

            if (substr($pathinfo, -1) !== '/') {
                return $this->redirect($pathinfo.'/', 'admin_category_translations');
            }

            return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_category_translations')), array (  '_controller' => 'AppBundle\\Controller\\Admin\\CategoryController::translationsAction',  '_locale' => 'it',));
        }
        not_admin_category_translations:

        // admin_category_translation_add
        if (preg_match('#^/(?P<_locale>it|en|fr|de|ru|es)/admin/category/(?P<id>[^/]++)/translations/add/(?P<localeCategory>[^/]++)/(?P<localeTranslation>[^/]++)$#s', $pathinfo, $matches)) {
            if (!in_array($this->context->getMethod(), array('GET', 'POST', 'HEAD'))) {
                $allow = array_merge($allow, array('GET', 'POST', 'HEAD'));
                goto not_admin_category_translation_add;
            }

            return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_category_translation_add')), array (  '_controller' => 'AppBundle\\Controller\\Admin\\CategoryController::addTranslationAction',  '_locale' => 'it',));
        }
        not_admin_category_translation_add:

        // admin_category_translation_edit
        if (preg_match('#^/(?P<_locale>it|en|fr|de|ru|es)/admin/category/(?P<idParent>[^/]++)/translations/(?P<id>[^/]++)/edit/(?P<localeCategory>[^/]++)/(?P<localeTranslation>[^/]++)$#s', $pathinfo, $matches)) {
            if (!in_array($this->context->getMethod(), array('GET', 'POST', 'HEAD'))) {
                $allow = array_merge($allow, array('GET', 'POST', 'HEAD'));
                goto not_admin_category_translation_edit;
            }

            return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_category_translation_edit')), array (  '_controller' => 'AppBundle\\Controller\\Admin\\CategoryController::editTranslationAction',  '_locale' => 'it',));
        }
        not_admin_category_translation_edit:

        // admin_category_delete
        if (preg_match('#^/(?P<_locale>it|en|fr|de|ru|es)/admin/category/(?P<id>[^/]++)/delete/$#s', $pathinfo, $matches)) {
            if ($this->context->getMethod() != 'DELETE') {
                $allow[] = 'DELETE';
                goto not_admin_category_delete;
            }

            return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_category_delete')), array (  '_controller' => 'AppBundle\\Controller\\Admin\\CategoryController::deleteAction',  '_locale' => 'it',));
        }
        not_admin_category_delete:

        // admin_content_home
        if (preg_match('#^/(?P<_locale>it|en|fr|de|ru|es)/admin/contents(?:/(?P<page>[^/]++)(?:/(?P<type>page|post))?)?$#s', $pathinfo, $matches)) {
            if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                $allow = array_merge($allow, array('GET', 'HEAD'));
                goto not_admin_content_home;
            }

            return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_content_home')), array (  'type' => NULL,  'page' => 1,  '_controller' => 'AppBundle\\Controller\\Admin\\ContentController::indexAction',  '_locale' => 'it',));
        }
        not_admin_content_home:

        // admin_content_new
        if (preg_match('#^/(?P<_locale>it|en|fr|de|ru|es)/admin/content/(?P<type>page|post)/new/?$#s', $pathinfo, $matches)) {
            if (!in_array($this->context->getMethod(), array('GET', 'POST', 'HEAD'))) {
                $allow = array_merge($allow, array('GET', 'POST', 'HEAD'));
                goto not_admin_content_new;
            }

            if (substr($pathinfo, -1) !== '/') {
                return $this->redirect($pathinfo.'/', 'admin_content_new');
            }

            return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_content_new')), array (  '_controller' => 'AppBundle\\Controller\\Admin\\ContentController::newAction',  '_locale' => 'it',));
        }
        not_admin_content_new:

        // admin_content_edit
        if (preg_match('#^/(?P<_locale>it|en|fr|de|ru|es)/admin/content/(?P<id>[^/]++)/edit/?$#s', $pathinfo, $matches)) {
            if (!in_array($this->context->getMethod(), array('GET', 'POST', 'HEAD'))) {
                $allow = array_merge($allow, array('GET', 'POST', 'HEAD'));
                goto not_admin_content_edit;
            }

            if (substr($pathinfo, -1) !== '/') {
                return $this->redirect($pathinfo.'/', 'admin_content_edit');
            }

            return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_content_edit')), array (  '_controller' => 'AppBundle\\Controller\\Admin\\ContentController::editAction',  '_locale' => 'it',));
        }
        not_admin_content_edit:

        // admin_content_translations
        if (preg_match('#^/(?P<_locale>it|en|fr|de|ru|es)/admin/content/(?P<id>[^/]++)/translations/?$#s', $pathinfo, $matches)) {
            if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                $allow = array_merge($allow, array('GET', 'HEAD'));
                goto not_admin_content_translations;
            }

            if (substr($pathinfo, -1) !== '/') {
                return $this->redirect($pathinfo.'/', 'admin_content_translations');
            }

            return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_content_translations')), array (  '_controller' => 'AppBundle\\Controller\\Admin\\ContentController::translationsAction',  '_locale' => 'it',));
        }
        not_admin_content_translations:

        // admin_content_translation_add
        if (preg_match('#^/(?P<_locale>it|en|fr|de|ru|es)/admin/content/(?P<id>[^/]++)/translations/add/(?P<localeContent>[^/]++)/(?P<localeTranslation>[^/]++)$#s', $pathinfo, $matches)) {
            if (!in_array($this->context->getMethod(), array('GET', 'POST', 'HEAD'))) {
                $allow = array_merge($allow, array('GET', 'POST', 'HEAD'));
                goto not_admin_content_translation_add;
            }

            return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_content_translation_add')), array (  '_controller' => 'AppBundle\\Controller\\Admin\\ContentController::addTranslationAction',  '_locale' => 'it',));
        }
        not_admin_content_translation_add:

        // admin_content_translation_edit
        if (preg_match('#^/(?P<_locale>it|en|fr|de|ru|es)/admin/content/(?P<idParent>[^/]++)/translations/(?P<id>[^/]++)/edit/(?P<localeContent>[^/]++)/(?P<localeTranslation>[^/]++)$#s', $pathinfo, $matches)) {
            if (!in_array($this->context->getMethod(), array('GET', 'POST', 'HEAD'))) {
                $allow = array_merge($allow, array('GET', 'POST', 'HEAD'));
                goto not_admin_content_translation_edit;
            }

            return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_content_translation_edit')), array (  '_controller' => 'AppBundle\\Controller\\Admin\\ContentController::editTranslationAction',  '_locale' => 'it',));
        }
        not_admin_content_translation_edit:

        // admin_content_delete
        if (preg_match('#^/(?P<_locale>it|en|fr|de|ru|es)/admin/content/(?P<id>[^/]++)/delete/$#s', $pathinfo, $matches)) {
            if ($this->context->getMethod() != 'DELETE') {
                $allow[] = 'DELETE';
                goto not_admin_content_delete;
            }

            return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_content_delete')), array (  '_controller' => 'AppBundle\\Controller\\Admin\\ContentController::deleteAction',  '_locale' => 'it',));
        }
        not_admin_content_delete:

        // admin_file_home
        if (preg_match('#^/(?P<_locale>it|en|fr|de|ru|es)/admin/files/?$#s', $pathinfo, $matches)) {
            if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                $allow = array_merge($allow, array('GET', 'HEAD'));
                goto not_admin_file_home;
            }

            if (substr($pathinfo, -1) !== '/') {
                return $this->redirect($pathinfo.'/', 'admin_file_home');
            }

            return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_file_home')), array (  'page' => 1,  '_controller' => 'AppBundle\\Controller\\Admin\\FileController::indexAction',  '_locale' => 'it',));
        }
        not_admin_file_home:

        // admin_file_home_page
        if (preg_match('#^/(?P<_locale>it|en|fr|de|ru|es)/admin/files/page\\-(?P<page>\\d+)$#s', $pathinfo, $matches)) {
            if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                $allow = array_merge($allow, array('GET', 'HEAD'));
                goto not_admin_file_home_page;
            }

            return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_file_home_page')), array (  '_controller' => 'AppBundle\\Controller\\Admin\\FileController::indexAction',  '_locale' => 'it',));
        }
        not_admin_file_home_page:

        // admin_file_upload
        if (preg_match('#^/(?P<_locale>it|en|fr|de|ru|es)/admin/file/upload$#s', $pathinfo, $matches)) {
            if (!in_array($this->context->getMethod(), array('GET', 'POST', 'HEAD'))) {
                $allow = array_merge($allow, array('GET', 'POST', 'HEAD'));
                goto not_admin_file_upload;
            }

            return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_file_upload')), array (  '_controller' => 'AppBundle\\Controller\\Admin\\FileController::uploadAction',  '_locale' => 'it',));
        }
        not_admin_file_upload:

        // admin_file_delete
        if (preg_match('#^/(?P<_locale>it|en|fr|de|ru|es)/admin/file/(?P<filename>[^/]++)/delete/?$#s', $pathinfo, $matches)) {
            if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                $allow = array_merge($allow, array('GET', 'HEAD'));
                goto not_admin_file_delete;
            }

            if (substr($pathinfo, -1) !== '/') {
                return $this->redirect($pathinfo.'/', 'admin_file_delete');
            }

            return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_file_delete')), array (  '_controller' => 'AppBundle\\Controller\\Admin\\FileController::deleteAction',  '_locale' => 'it',));
        }
        not_admin_file_delete:

        // admin_macrocategorieMag_home
        if (preg_match('#^/(?P<_locale>it|en|fr|de|ru|es)/admin/macrocategorieMag/?$#s', $pathinfo, $matches)) {
            if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                $allow = array_merge($allow, array('GET', 'HEAD'));
                goto not_admin_macrocategorieMag_home;
            }

            if (substr($pathinfo, -1) !== '/') {
                return $this->redirect($pathinfo.'/', 'admin_macrocategorieMag_home');
            }

            return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_macrocategorieMag_home')), array (  '_controller' => 'AppBundle\\Controller\\Admin\\MacrocategorieMagController::indexAction',  '_locale' => 'it',));
        }
        not_admin_macrocategorieMag_home:

        // admin_macrocategorieMag_new
        if (preg_match('#^/(?P<_locale>it|en|fr|de|ru|es)/admin/macrocategorieMagy/new/?$#s', $pathinfo, $matches)) {
            if (!in_array($this->context->getMethod(), array('GET', 'POST', 'HEAD'))) {
                $allow = array_merge($allow, array('GET', 'POST', 'HEAD'));
                goto not_admin_macrocategorieMag_new;
            }

            if (substr($pathinfo, -1) !== '/') {
                return $this->redirect($pathinfo.'/', 'admin_macrocategorieMag_new');
            }

            return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_macrocategorieMag_new')), array (  '_controller' => 'AppBundle\\Controller\\Admin\\MacrocategorieMagController::newAction',  '_locale' => 'it',));
        }
        not_admin_macrocategorieMag_new:

        // admin_macrocategorieMag_edit
        if (preg_match('#^/(?P<_locale>it|en|fr|de|ru|es)/admin/macrocategorieMagy/(?P<id>[^/]++)/edit/?$#s', $pathinfo, $matches)) {
            if (!in_array($this->context->getMethod(), array('GET', 'POST', 'HEAD'))) {
                $allow = array_merge($allow, array('GET', 'POST', 'HEAD'));
                goto not_admin_macrocategorieMag_edit;
            }

            if (substr($pathinfo, -1) !== '/') {
                return $this->redirect($pathinfo.'/', 'admin_macrocategorieMag_edit');
            }

            return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_macrocategorieMag_edit')), array (  '_controller' => 'AppBundle\\Controller\\Admin\\MacrocategorieMagController::editAction',  '_locale' => 'it',));
        }
        not_admin_macrocategorieMag_edit:

        // admin_macrocategorieMag_translations
        if (preg_match('#^/(?P<_locale>it|en|fr|de|ru|es)/admin/macrocategorieMagy/(?P<id>[^/]++)/translations/?$#s', $pathinfo, $matches)) {
            if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                $allow = array_merge($allow, array('GET', 'HEAD'));
                goto not_admin_macrocategorieMag_translations;
            }

            if (substr($pathinfo, -1) !== '/') {
                return $this->redirect($pathinfo.'/', 'admin_macrocategorieMag_translations');
            }

            return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_macrocategorieMag_translations')), array (  '_controller' => 'AppBundle\\Controller\\Admin\\MacrocategorieMagController::translationsAction',  '_locale' => 'it',));
        }
        not_admin_macrocategorieMag_translations:

        // admin_macrocategorieMag_translation_add
        if (preg_match('#^/(?P<_locale>it|en|fr|de|ru|es)/admin/macrocategorieMagy/(?P<id>[^/]++)/translations/add/(?P<localeMacrocategorieMag>[^/]++)/(?P<localeTranslation>[^/]++)$#s', $pathinfo, $matches)) {
            if (!in_array($this->context->getMethod(), array('GET', 'POST', 'HEAD'))) {
                $allow = array_merge($allow, array('GET', 'POST', 'HEAD'));
                goto not_admin_macrocategorieMag_translation_add;
            }

            return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_macrocategorieMag_translation_add')), array (  '_controller' => 'AppBundle\\Controller\\Admin\\MacrocategorieMagController::addTranslationAction',  '_locale' => 'it',));
        }
        not_admin_macrocategorieMag_translation_add:

        // admin_macrocategorieMag_translation_edit
        if (preg_match('#^/(?P<_locale>it|en|fr|de|ru|es)/admin/macrocategorieMagy/(?P<idParent>[^/]++)/translations/(?P<id>[^/]++)/edit/(?P<localeMacrocategorieMag>[^/]++)/(?P<localeTranslation>[^/]++)$#s', $pathinfo, $matches)) {
            if (!in_array($this->context->getMethod(), array('GET', 'POST', 'HEAD'))) {
                $allow = array_merge($allow, array('GET', 'POST', 'HEAD'));
                goto not_admin_macrocategorieMag_translation_edit;
            }

            return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_macrocategorieMag_translation_edit')), array (  '_controller' => 'AppBundle\\Controller\\Admin\\MacrocategorieMagController::editTranslationAction',  '_locale' => 'it',));
        }
        not_admin_macrocategorieMag_translation_edit:

        // admin_macrocategorieMag_delete
        if (preg_match('#^/(?P<_locale>it|en|fr|de|ru|es)/admin/macrocategorieMagy/(?P<id>[^/]++)/delete/$#s', $pathinfo, $matches)) {
            if ($this->context->getMethod() != 'DELETE') {
                $allow[] = 'DELETE';
                goto not_admin_macrocategorieMag_delete;
            }

            return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_macrocategorieMag_delete')), array (  '_controller' => 'AppBundle\\Controller\\Admin\\MacrocategorieMagController::deleteAction',  '_locale' => 'it',));
        }
        not_admin_macrocategorieMag_delete:

        // admin_nav_home
        if (preg_match('#^/(?P<_locale>it|en|fr|de|ru|es)/admin/navs/?$#s', $pathinfo, $matches)) {
            if (substr($pathinfo, -1) !== '/') {
                return $this->redirect($pathinfo.'/', 'admin_nav_home');
            }

            return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_nav_home')), array (  '_controller' => 'AppBundle\\Controller\\Admin\\NavController::indexAction',  '_locale' => 'it',));
        }

        // admin_nav_new
        if (preg_match('#^/(?P<_locale>it|en|fr|de|ru|es)/admin/nav/new/?$#s', $pathinfo, $matches)) {
            if (substr($pathinfo, -1) !== '/') {
                return $this->redirect($pathinfo.'/', 'admin_nav_new');
            }

            return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_nav_new')), array (  'idRemove' => NULL,  '_controller' => 'AppBundle\\Controller\\Admin\\NavController::newAction',  '_locale' => 'it',));
        }

        // admin_nav_new_remove_element
        if (preg_match('#^/(?P<_locale>it|en|fr|de|ru|es)/admin/nav/new(?:/(?P<idRemove>\\d+))?$#s', $pathinfo, $matches)) {
            return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_nav_new_remove_element')), array (  'idRemove' => NULL,  '_controller' => 'AppBundle\\Controller\\Admin\\NavController::newAction',  '_locale' => 'it',));
        }

        // admin_nav_edit
        if (preg_match('#^/(?P<_locale>it|en|fr|de|ru|es)/admin/nav/edit/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
            return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_nav_edit')), array (  'nav' => NULL,  'idRemove' => NULL,  '_controller' => 'AppBundle\\Controller\\Admin\\NavController::editAction',  '_locale' => 'it',));
        }

        // admin_nav_edit_remove_element
        if (preg_match('#^/(?P<_locale>it|en|fr|de|ru|es)/admin/nav/edit/(?P<id>[^/]++)(?:/(?P<idRemove>\\d+))?$#s', $pathinfo, $matches)) {
            return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_nav_edit_remove_element')), array (  'nav' => NULL,  'idRemove' => NULL,  '_controller' => 'AppBundle\\Controller\\Admin\\NavController::editAction',  '_locale' => 'it',));
        }

        // admin_nav_delete
        if (preg_match('#^/(?P<_locale>it|en|fr|de|ru|es)/admin/nav/(?P<id>[^/]++)/delete/$#s', $pathinfo, $matches)) {
            if ($this->context->getMethod() != 'DELETE') {
                $allow[] = 'DELETE';
                goto not_admin_nav_delete;
            }

            return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_nav_delete')), array (  '_controller' => 'AppBundle\\Controller\\Admin\\NavController::deleteAction',  '_locale' => 'it',));
        }
        not_admin_nav_delete:

        // admin_nav_translations
        if (preg_match('#^/(?P<_locale>it|en|fr|de|ru|es)/admin/nav/(?P<id>[^/]++)/translations/?$#s', $pathinfo, $matches)) {
            if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                $allow = array_merge($allow, array('GET', 'HEAD'));
                goto not_admin_nav_translations;
            }

            if (substr($pathinfo, -1) !== '/') {
                return $this->redirect($pathinfo.'/', 'admin_nav_translations');
            }

            return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_nav_translations')), array (  '_controller' => 'AppBundle\\Controller\\Admin\\NavController::translationsAction',  '_locale' => 'it',));
        }
        not_admin_nav_translations:

        // admin_nav_translation_generate
        if (preg_match('#^/(?P<_locale>it|en|fr|de|ru|es)/admin/nav/(?P<id>[^/]++)/translations/generate/(?P<localeNav>[^/]++)/(?P<localeTranslation>[^/]++)$#s', $pathinfo, $matches)) {
            if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                $allow = array_merge($allow, array('GET', 'HEAD'));
                goto not_admin_nav_translation_generate;
            }

            return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_nav_translation_generate')), array (  '_controller' => 'AppBundle\\Controller\\Admin\\NavController::generateTranslationAction',  '_locale' => 'it',));
        }
        not_admin_nav_translation_generate:

        // admin_nav_translation_update
        if (preg_match('#^/(?P<_locale>it|en|fr|de|ru|es)/admin/nav/(?P<id>[^/]++)/translations/update/(?P<localeNav>[^/]++)/(?P<localeTranslation>[^/]++)$#s', $pathinfo, $matches)) {
            if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                $allow = array_merge($allow, array('GET', 'HEAD'));
                goto not_admin_nav_translation_update;
            }

            return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_nav_translation_update')), array (  '_controller' => 'AppBundle\\Controller\\Admin\\NavController::updateTranslationAction',  '_locale' => 'it',));
        }
        not_admin_nav_translation_update:

        // login_route
        if (preg_match('#^/(?P<_locale>it|en|fr|de|ru|es)/admin/login$#s', $pathinfo, $matches)) {
            return $this->mergeDefaults(array_replace($matches, array('_route' => 'login_route')), array (  '_controller' => 'AppBundle\\Controller\\Admin\\SecurityController::loginAction',  '_locale' => 'it',));
        }

        // login_check_route
        if (preg_match('#^/(?P<_locale>it|en|fr|de|ru|es)/admin/login_check$#s', $pathinfo, $matches)) {
            return $this->mergeDefaults(array_replace($matches, array('_route' => 'login_check_route')), array (  '_controller' => 'AppBundle\\Controller\\Admin\\SecurityController::loginCheckAction',  '_locale' => 'it',));
        }

        // logout_route
        if (preg_match('#^/(?P<_locale>it|en|fr|de|ru|es)/admin/logout$#s', $pathinfo, $matches)) {
            return $this->mergeDefaults(array_replace($matches, array('_route' => 'logout_route')), array (  '_controller' => 'AppBundle\\Controller\\Admin\\SecurityController::logoutAction',  '_locale' => 'it',));
        }

        // app_index
        if (preg_match('#^/(?P<_locale>it|en|fr|de|ru|es)/?$#s', $pathinfo, $matches)) {
            if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                $allow = array_merge($allow, array('GET', 'HEAD'));
                goto not_app_index;
            }

            if (substr($pathinfo, -1) !== '/') {
                return $this->redirect($pathinfo.'/', 'app_index');
            }

            return $this->mergeDefaults(array_replace($matches, array('_route' => 'app_index')), array (  '_controller' => 'AppBundle\\Controller\\AppController::indexAction',  '_locale' => 'it',));
        }
        not_app_index:

        // app_page
        if (preg_match('#^/(?P<_locale>it|en|fr|de|ru|es)/(?P<slug>[^/]++)$#s', $pathinfo, $matches)) {
            if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                $allow = array_merge($allow, array('GET', 'HEAD'));
                goto not_app_page;
            }

            return $this->mergeDefaults(array_replace($matches, array('_route' => 'app_page')), array (  '_controller' => 'AppBundle\\Controller\\AppController::pageAction',  '_locale' => 'it',));
        }
        not_app_page:

        // app_blog_index
        if (preg_match('#^/(?P<_locale>it|en|fr|de|ru|es)/blog/?$#s', $pathinfo, $matches)) {
            if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                $allow = array_merge($allow, array('GET', 'HEAD'));
                goto not_app_blog_index;
            }

            if (substr($pathinfo, -1) !== '/') {
                return $this->redirect($pathinfo.'/', 'app_blog_index');
            }

            return $this->mergeDefaults(array_replace($matches, array('_route' => 'app_blog_index')), array (  'page' => 1,  '_controller' => 'AppBundle\\Controller\\BlogController::indexAction',  '_locale' => 'it',));
        }
        not_app_blog_index:

        // app_blog_index_paginated
        if (preg_match('#^/(?P<_locale>it|en|fr|de|ru|es)/blog/(?P<page>\\d+)$#s', $pathinfo, $matches)) {
            if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                $allow = array_merge($allow, array('GET', 'HEAD'));
                goto not_app_blog_index_paginated;
            }

            return $this->mergeDefaults(array_replace($matches, array('_route' => 'app_blog_index_paginated')), array (  '_controller' => 'AppBundle\\Controller\\BlogController::indexAction',  '_locale' => 'it',));
        }
        not_app_blog_index_paginated:

        // app_blog_category
        if (preg_match('#^/(?P<_locale>it|en|fr|de|ru|es)/blog/(?P<slug>[^/]++)$#s', $pathinfo, $matches)) {
            if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                $allow = array_merge($allow, array('GET', 'HEAD'));
                goto not_app_blog_category;
            }

            return $this->mergeDefaults(array_replace($matches, array('_route' => 'app_blog_category')), array (  'page' => 1,  '_controller' => 'AppBundle\\Controller\\BlogController::categoryAction',  '_locale' => 'it',));
        }
        not_app_blog_category:

        // app_blog_category_paginated
        if (preg_match('#^/(?P<_locale>it|en|fr|de|ru|es)/blog/(?P<slug>[^/]++)/(?P<page>\\d+)$#s', $pathinfo, $matches)) {
            if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                $allow = array_merge($allow, array('GET', 'HEAD'));
                goto not_app_blog_category_paginated;
            }

            return $this->mergeDefaults(array_replace($matches, array('_route' => 'app_blog_category_paginated')), array (  '_controller' => 'AppBundle\\Controller\\BlogController::categoryAction',  '_locale' => 'it',));
        }
        not_app_blog_category_paginated:

        // app_blog_post
        if (preg_match('#^/(?P<_locale>it|en|fr|de|ru|es)/blog/(?P<slugcategory>[^/]++)/(?P<slug>[^/]++)$#s', $pathinfo, $matches)) {
            if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                $allow = array_merge($allow, array('GET', 'HEAD'));
                goto not_app_blog_post;
            }

            return $this->mergeDefaults(array_replace($matches, array('_route' => 'app_blog_post')), array (  '_controller' => 'AppBundle\\Controller\\BlogController::postShowAction',  '_locale' => 'it',));
        }
        not_app_blog_post:

        throw 0 < count($allow) ? new MethodNotAllowedException(array_unique($allow)) : new ResourceNotFoundException();
    }
}
