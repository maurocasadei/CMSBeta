function callback_tinymce_init(editor) {

	$('textarea.tinymce').each(function (){
		  //$(this).tinymce();
		  //alert("dddd");
		  //alert($(this).name);
	});

}
